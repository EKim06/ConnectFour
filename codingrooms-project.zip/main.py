"""
Eric Kim 2023
This program is a Connect Four game
The game board is 6 columns wide and 5 rows tall
You can play with a simple NPC if desired

"""

#Global Variables
board = []
player = "X"
optimalCol = -1

#Prepares the board
print("\t\tWelcome to Connect Four!")
for i in range(5):
        board.append(["-"]*6)

#Prints board onto the screen
def print_board():
    print("\t0\t1\t2\t3\t4\t5")
    for item in board:
        row = ""
        for space in item:
            row += "\t" + space 
        print(row + "\n")

#Checks if user move is valid then places the user on the lowest space in that column
def check_and_place(player,col):
    if(col<0 or col>5):
        return False
    else:
        row = 4
        for i in range(5):
            if(board[row][col]=="-"):
                board[row][col] = player
                return True
            row -= 1
        return False



#Prompts the user to make a move 
def take_turn(player):
    print(player , "'s Turn")
    col = int(input("Enter a column: "))
    while(not check_and_place(player,col)):
        print("Please enter a valid move")
        col = int(input("Enter a column: "))
    print_board()

#Checks for 4 in a column
def check_col_win(player):
    row = 4
    for i in range(2):
        for col in range(6):
            if(board[row][col]==board[row-1][col]==board[row-2][col]==board[row-3][col]==player):
                return True
        row -= 1
    return False

#Checks for 4 in a row
def check_row_win(player):
    col = 0
    for i in range(3):
        for row in range(5):
            if(board[row][col]==board[row][col+1]==board[row][col+2]==board[row][col+3]==player):
                return True
        col += 1
    return False

#Checks for 4 in a diagonal
def check_diag_win(player):
    row = 4
    for i in range(2):
        col = 0
        for i in range(3): #checks for all instances of diagonals that look like "/"
            if(board[row][col]==board[row-1][col+1]==board[row-2][col+2]==board[row-3][col+3]==player):
                return True
            col += 1
        col = 5
        for i in range(3): #checks for all instances of diagonals that look like "\"
            if(board[row][col]==board[row-1][col-1]==board[row-2][col-2]==board[row-3][col-3]==player):
                return True
            col -= 1
        row -= 1
    return False

#Combines all the win conditions
def check_win(player):
    return check_col_win(player) or check_row_win(player) or check_diag_win(player)
    
#Checks if there is a tie
def check_tie():
    for i in range(5):
        if("-" in board[i]): #if there is still empty space on the board
            return False
    return not check_win("X") and not check_win("O")

#Prints the result of the game
def print_results():
    if check_win("X"):
        print("X wins!")
    elif check_win("O"):
        print("O wins!")
    else:
        print("It's a tie!")


#Start of main program
print_board()
while(not check_win("X") and not check_win("O") and not check_tie()):
    take_turn(player)
    if(player == "X"):
        player = "O"
    else:
        player = "X"
print_results()

    


